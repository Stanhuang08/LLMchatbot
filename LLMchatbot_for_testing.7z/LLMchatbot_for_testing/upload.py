import gradio as gr
import os
from zipfile import ZipFile
from llama_index import (
    SimpleDirectoryReader,
    LLMPredictor,
    PromptHelper,
    ServiceContext,
    VectorStoreIndex,
)

from llama_index.llms import AzureOpenAI
from llama_index.embeddings import AzureOpenAIEmbedding
from io import StringIO

log_stream = StringIO()

PORT = 8888
extractDir = "output_ei/"
indexDir = "index-ei/"

api_version3 = "2023-03-15-preview"
azure_endpoint3 = "https://ltc-to-openai.openai.azure.com/"
api_key3 = "0f1a03e98a2046218282e875964f5cc6"

max_input_size = 4096
num_output = 1024
max_chunk_overlap = 1

llm = AzureOpenAI(
    temperature = 0, 
    max_tokens = 4096,
    deployment_name="gpt-35-turbo-0301", 
    model = "gpt-35-turbo",
#    deployment_name = "text-davinci-003", 
#    model = "text-davinci-003",
    api_key = api_key3,
    azure_endpoint = azure_endpoint3,
    api_version = api_version3,
)


llm_predictor = LLMPredictor(llm=llm)
embed_model = AzureOpenAIEmbedding(
    model="text-embedding-ada-002",
    deployment_name="text-embedding-ada-002",
    api_key=api_key3,
    azure_endpoint=azure_endpoint3,
    api_version=api_version3,
)

prompt_helper = PromptHelper(max_input_size, num_output, max_chunk_overlap)
service_context = ServiceContext.from_defaults(
    llm_predictor=llm_predictor,
    embed_model= embed_model,
    prompt_helper=prompt_helper
)

def extractUploadFile(file_obj):
    try:
        if os.path.exists(extractDir):
            return "已有一個 Index 作業進行中，請稍後再試..."
        with ZipFile(file_obj.name, mode="r") as zip:
            zip.extractall(extractDir)
        reBuildIndex()
        nukedir(extractDir)
        return "Index 重建作業完成，請重新載入網頁。"
    except Exception as e:
        nukedir(extractDir)
        return "重建發生錯誤：" + str(e)

def nukedir(dir):
    if dir[-1] == os.sep: dir = dir[:-1]
    files = os.listdir(dir)
    for file in files:
        if file == '.' or file == '..': continue
        path = dir + os.sep + file
        if os.path.isdir(path):
            nukedir(path)
        else:
            os.unlink(path)
    os.rmdir(dir)
   
def reBuildIndex():
    documents = SimpleDirectoryReader(extractDir).load_data()
    index = VectorStoreIndex.from_documents(documents, service_context=service_context)
    index.storage_context.persist(persist_dir=indexDir)

def ReadLog():
    return log_stream.getvalue()

def ClearLog():
    log_stream.truncate(0)
    return "Cleared."


with gr.Blocks(title="ChatGPT chatbot files upload & Logs check") as demo:
    gr.Markdown(
    """
    # ChatGPT chatbot files upload & Logs check
    """)
    with gr.Tab("Re-Index"):
        txtFile = gr.Textbox(lines=15,label="Upload ready to index")
        btnFile = gr.UploadButton(label="Upload", file_count="single", type="file")
        btnFile.upload(extractUploadFile, inputs=btnFile, outputs=[txtFile])
    with gr.Tab("Logs"):
        txtLog = gr.Textbox(lines=15,label="Log data")
        with gr.Row():
            btnLog = gr.Button(value="Read Log")
            btnLog.click(ReadLog, None, txtLog)
            btnCls = gr.Button(value="Clear Log")
            btnCls.click(ClearLog, None, txtLog)
            
if __name__ == '__main__':
    demo.launch(server_name="0.0.0.0", server_port=PORT)
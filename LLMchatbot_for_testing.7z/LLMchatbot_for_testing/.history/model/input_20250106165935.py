from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str

    @validator("input_text", pre=True)
    def validate_quotes(cls, value):
        if '"' in value:  # 檢查是否包含非法雙引號
            raise ValueError("invalid input: 請求體中包含非法的雙引號")
        return value
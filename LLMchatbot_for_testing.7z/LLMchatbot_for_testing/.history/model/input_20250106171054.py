from pydantic import BaseModel, validator


class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str

    @validator('input_text', pre=True)
    def sanitize_input_text(cls, v):
        if isinstance(v, str):
            # 處理輸入文本中的引號
            sanitized = v.replace('"', '\\"')
            # 確保可以被正確地解析為 JSON
            try:
                # 測試是否可以被正確序列化
                json.dumps({"text": sanitized})
                return sanitized
            except json.JSONDecodeError:
                # 如果序列化失敗，返回轉義後的字符串
                return json.dumps(v)[1:-1]  # 移除 json.dumps 添加的外層引號
        return v

    class Config:
        # 允許額外的字段
        extra = "allow"
        # 使用自定義的 JSON 編碼器
        json_encoders = {
            str: lambda v: v.replace('"', '\\"')
        }
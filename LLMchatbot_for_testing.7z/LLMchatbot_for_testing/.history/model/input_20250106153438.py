from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str
    # topkrelevant: int
    
    @validator("input_text")
    def escape_special_characters(cls, value):
        """
        自動處理 input_text 中的特殊字符，例如轉義雙引號。
        """
        if '"' in value:
            # 將雙引號轉義為 \" 並返回新的值
            value = value.replace('"', '\\"')
        return value
from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str


        @validator('input_text')
        def check_for_quotes(cls, value):
            if '"' in value:
                raise ValueError('input_text should not contain double quotes')
            return value
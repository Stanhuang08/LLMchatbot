from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str

    @validator('input_text')
    def escape_quotes(cls, v):
        # 替換引號為轉義後的引號
        return v.replace('"', '\\"')

    class Config:
        # 允許額外的引號處理
        json_encoders = {
            str: lambda v: v.replace('"', '\\"')
        }
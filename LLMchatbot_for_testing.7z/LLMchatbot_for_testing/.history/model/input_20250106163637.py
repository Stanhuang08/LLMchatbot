from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str
    @validator('input_text')
    def replace_double_quotes(cls, v):
        if not isinstance(v, str):
            raise ValueError('input_text must be a string')
        return v.replace('"', "'")
from pydantic import BaseModel, validator

class Input(BaseModel):
    site_id: str
    user_id: str
    input_text: str
    @validator('input_text', pre=True, always=True)
    def replace_text(cls, v):
        return v.replace('"', "'")
import os
import psycopg2          
from datetime import datetime

class DataStore:
    def __init__(self):
        self.connection = None
        self.cursor = None

    def make_connection(self):
        try:
            self.connection = psycopg2.connect(
                user=os.environ.get('POSTGRES_USER'),
                password=os.environ.get('POSTGRES_PASSWORD'),
                host=os.environ.get('PGSQL_HOST'),
                port=os.environ.get('PGSQL_PORT'),
                database=os.environ.get('POSTGRES_DB')
            )
            
            self.cursor = self.connection.cursor()
            
            print(self.connection.get_dsn_parameters(), "\n")
    
            
            self.cursor.execute("SELECT version();")
            record = self.cursor.fetchone()
            print("You are connected to - ", record, "\n")
    
        except (Exception, psycopg2.Error) as error:
            print("Error while connecting to PostgreSQL", error)
    
        return self.connection, self.cursor
    
    def close_connection(self):
        if self.connection:
            self.cursor.close()
            self.connection.close()
            print("PostgreSQL connection is closed")
    
    def get_current_utc_time(self):
        current_utc_time = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        return current_utc_time
    
    def write_query(self, site_id, user_id, ask, answer, current_utc_time):
        query = f"INSERT INTO public.chatbot_log (site_id, user_id, ask, answer, timestamp) VALUES ('{site_id}', '{user_id}', '{ask}', '{answer}', '{current_utc_time}')"
        self.cursor.execute(query)
        self.connection.commit()
        
    def store_data(self, site_id, user_id, ask, answer):
        self.make_connection()
        current_utc_time = self.get_current_utc_time()
        self.write_query(site_id, user_id, ask, answer, current_utc_time)
        self.close_connection()
from fastapi import Security, HTTPException, status
from fastapi.security import APIKeyHeader
 
 
 
api_key_header = APIKeyHeader(name="Authorization")
 
 
def get_user(api_key: str = Security(api_key_header)):
     return api_key